# Artificial Intelligence-Based Early Diabetes Prediction Using Machine Learning

## Published Research Paper

This repository contains the published research paper and its publication certificates.

### Publication details
- **Paper title:** Artificial Intelligence-Based Early Diabetes Prediction Using Machine Learning
- **Journal:** International Journal of Engineering Development and Research (IJEDR)
- **Volume / Issue:** Volume 14, Issue 4
- **Publication date shown on certificate:** 19 October 2026
- **Paper ID:** IJEDR2604153
- **Authors:** Manasa V, Rakshitha S, and Jayanth A R
- **Institution:** KLE Society's S Nijalingappa College, Bengaluru, India

### Repository contents
- `research-paper/IJEDR2604153.pdf` — Published research paper (8 pages).
- `certificates/IJEDR_Publication_Certificates_Registration_309788.pdf` — Publication certificate PDF (contains certificate pages for the listed authors).

### Research overview
The paper compares five machine-learning classifiers using the Pima Indians Diabetes Dataset:
- Logistic Regression
- Decision Tree
- Random Forest
- Support Vector Machine (SVM)
- K-Nearest Neighbours (KNN)

The study describes an 80:20 stratified train-test split, five-fold stratified cross-validation, leakage-aware preprocessing, Random Forest hyperparameter tuning, permutation feature importance, confusion-matrix analysis, and a learning curve.

### Reported result
On the primary held-out test split, the tuned Random Forest reported 74.03% accuracy and 81.54% ROC-AUC. The paper also reports results for the other evaluated classifiers and additional robustness analysis.

### Important note
This repository shares the work for academic and portfolio purposes. As stated in the paper, the model is a research prototype and is **not a substitute for professional medical diagnosis**.

